#!/bin/bash
##Snort on LINUX

apt-get install bison flex gcc libdnet libdumbnet-dev libluajit-5.1-dev libnghttp2-dev libpcap-dev libpcre3-dev libssl-dev make openssl wget zlib1g-dev sudo -y 

mkdir /usr/src/snort_src


cd $_
wget -q http://192.168.74.3/sw/security_tools/snort/daq-2.0.6.tar.gz
ls
tar -xvf daq-2.0.6.tar.gz
ls
cd daq-2.0.6
ls
./configure
make
make install
cd /usr/src/snort_src
wget -q http://192.168.74.3/sw/security_tools/snort/snort-2.9.15.tar.gz
tar -xvf snort-2.9.15.tar.gz
### -------------------
# sudo snort -V
cd snort-2.9.15

./configure --enable-sourcefire 

ldconfig

#sudo snort -V

which snort

ln -s /usr/local/bin/snort /usr/sbin/snort

#sudo snort -V

groupadd snort

useradd snort -r -s /usr/sbin/nologin -c SNORT_IDS -g snort

mkdir -p /etc/snort/rules
mkdir -p /var/log/snort
mkdir -p /usr/local/lib/snort_dynamicrules

# sudo cp -arv rules /etc/snort/ 

cp /usr/src/snort_src/snort-2.9.15/etc/*.conf* /etc/snort/
cp /usr/src/snort_src/snort-2.9.15/etc/*.map /etc/snort/

###Copying conf file to location ###
#sudo cp -av snort.conf /etc/snort/
touch /etc/snort/rules/{white_list.rules,black_list.rules,local.rules}
ls -l /etc/snort/rules/

chmod 5775 /etc/snort
chmod 5775 /var/log/snort/
chmod 5775 /usr/local/lib/snort_dynamicrules

chown -R snort:snort /etc/snort
chown -R snort:snort /var/log/snort/
chown -R snort:snort /usr/local/lib/snort_dynamicrules/

cp -av /etc/snort/snort.conf{,.backup} 

#sudo nano /etc/snort/snort.conf

cp -av /root/snort.conf /etc/snort/snort.conf
cp -av /root/local.rules /etc/snort/rules/local.rules

#snort -T -c /etc/snort/snort.conf
snort -i ens33 -u snort -g snort -c /etc/snort/snort.conf -A console
